package com.company.DBExceptions;

public enum StorageType {
    DATABASE, TABLE, ROW, COLUMN, FILE
}
