package com.company.DBExceptions;

public abstract class DBException extends Exception{

    public DBException(){}
}
