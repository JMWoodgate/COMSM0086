package com.company.DBCommand;

public enum LiteralType {
    STRING, BOOLEAN, INTEGER, FLOAT
}
