package com.company.DBCommand;

public enum AlterationType {
    ADD, DROP
}
